/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defaultA;

import controller.ManageEastAsiaCountries;

/**
 *
 * @author suunh
 */
public class main {
    public static void main(String[] args) {
        ManageEastAsiaCountries ma = new ManageEastAsiaCountries();
        ma.run();
    }
    //1
}
