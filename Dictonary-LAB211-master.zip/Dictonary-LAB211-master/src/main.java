
import controller.ManagerDiction;


public class main {
    public static void main(String[] args) {
        ManagerDiction dic = new ManagerDiction();
        dic.run();
    }
}
