
import controller.AnalysisStringProgram;


public class Main {

    public static void main(String[] args) {
        new AnalysisStringProgram().run();

    }
}
