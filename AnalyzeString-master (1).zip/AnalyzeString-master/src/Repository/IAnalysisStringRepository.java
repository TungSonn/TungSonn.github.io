package Repository;

public interface IAnalysisStringRepository {
    void analysisString();
}
