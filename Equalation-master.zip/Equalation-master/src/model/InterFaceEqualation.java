/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public interface InterFaceEqualation {

    void superlativeEquation();

    void quadraticEquation();

    void inra(double a[]);

    ArrayList<ArrayList<Double>> checkNumber(double[] a);

    void display(ArrayList<Double> list);
}
