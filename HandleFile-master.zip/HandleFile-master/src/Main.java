
import controller.PersonManagement;


/**
 *
 * @author ASUS
 */
public class Main {
    public static void main(String[] args) {
        PersonManagement pmn = new PersonManagement();
        pmn.run();
    }
}
